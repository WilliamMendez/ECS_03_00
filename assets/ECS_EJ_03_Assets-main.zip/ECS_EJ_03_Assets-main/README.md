# ECS_EJ_03_Assets
Ejemplos de archivos de configuración e imagen que serán usados para el ejercicio de la semana 03
